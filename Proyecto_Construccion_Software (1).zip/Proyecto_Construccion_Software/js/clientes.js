document.addEventListener('DOMContentLoaded', function() {
    // Referencias a elementos del DOM
    const tableBody = document.querySelector('#clients-table tbody');
    const addClientBtn = document.getElementById('add-client');
    const clientModal = document.getElementById('client-modal');
    const clientForm = document.getElementById('client-form');
    const modalTitle = document.getElementById('modal-title');
    const searchName = document.getElementById('search-name');
    const searchCedula = document.getElementById('search-cedula');
    
    // Cargar clientes desde localStorage
    let clients = JSON.parse(localStorage.getItem('taller_clientes')) || [];

    // Muestra el modal para crear/editar cliente
    function showClientModal(client = null) {
        if (client) {
            // Modo edición: Rellena el formulario con datos existentes
            modalTitle.textContent = 'Editar Cliente';
            document.getElementById('client-name').value = client.nombre;
            document.getElementById('client-cedula').value = client.cedula || '';
            document.getElementById('client-phone').value = client.telefono || '';
            document.getElementById('client-email').value = client.email || '';
            document.getElementById('client-address').value = client.direccion || '';
            clientForm.dataset.id = client.id;
        } else {
            // Modo creación: Limpia el formulario
            modalTitle.textContent = 'Nuevo Cliente';
            clientForm.reset();
            delete clientForm.dataset.id;
        }
        clientModal.style.display = 'flex';
    }

    // Busca clientes según criterios de búsqueda
    function searchClients() {
        const nameTerm = searchName.value.toLowerCase();
        const cedulaTerm = searchCedula.value.toLowerCase();
        
        return clients.filter(client => {
            const nameMatch = client.nombre.toLowerCase().includes(nameTerm);
            const cedulaMatch = client.cedula && client.cedula.toLowerCase().includes(cedulaTerm);
            // Aplicar filtros según qué campos se han llenado
            if (searchName.value && searchCedula.value) {
                return nameMatch && cedulaMatch;
            } else if (searchName.value) {
                return nameMatch;
            } else if (searchCedula.value) {
                return cedulaMatch;
            }
            return true;
        });
    }

    // Renderizar clientes
    function renderClients(clientsToRender = clients) {
        tableBody.innerHTML = '';
        
        const filteredClients = clientsToRender.length ? clientsToRender : clients;
         // Crear fila para cada cliente
        filteredClients.forEach(client => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${client.id}</td>
                <td>${client.nombre}</td>
                <td>${client.cedula || 'N/A'}</td>
                <td>${client.telefono || 'N/A'}</td>
                <td>${client.email || 'N/A'}</td>
                <td>${client.direccion || 'N/A'}</td>
                <td>
                    <button class="btn-action edit" data-id="${client.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-action delete" data-id="${client.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
             // Evento para editar cliente
            row.querySelector('.edit').addEventListener('click', () => {
                showClientModal(clients.find(c => c.id == client.id));
            });
            // Evento para eliminar cliente
            row.querySelector('.delete').addEventListener('click', () => {
                if (confirm('¿Estás seguro de eliminar este cliente?')) {
                    clients = clients.filter(c => c.id != client.id);
                    localStorage.setItem('taller_clientes', JSON.stringify(clients));
                    renderClients();
                    showNotification('Cliente eliminado correctamente', 'success');
                }
            });
            
            tableBody.appendChild(row);
        });
    }

    // Guardar cliente
    clientForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Recopilar datos del formulario
        const clientData = {
            nombre: document.getElementById('client-name').value,
            cedula: document.getElementById('client-cedula').value,
            telefono: document.getElementById('client-phone').value,
            email: document.getElementById('client-email').value,
            direccion: document.getElementById('client-address').value
        };
      // Validación de campos obligatorios
        if (!clientData.nombre || !clientData.cedula || !clientData.telefono) {
            showNotification('Por favor complete los campos obligatorios (*)', 'error');
            return;
        }

        if (this.dataset.id) {
            //  Modo edición: Actualizar cliente existente
            const index = clients.findIndex(c => c.id == this.dataset.id);
            if (index !== -1) {
                clientData.id = clients[index].id;
                clients[index] = clientData;
                showNotification('Cliente actualizado correctamente', 'success');
            }
        } else {
            // Modo creación: Crear nuevo cliente
            clientData.id = Date.now();
            clients.push(clientData);
            showNotification('Cliente creado correctamente', 'success');
        }
         // Guardar en localStorage y actualizar UI
        localStorage.setItem('taller_clientes', JSON.stringify(clients));
        clientModal.style.display = 'none';
        renderClients();
    });

    // Eventos de búsqueda
    searchName.addEventListener('input', () => renderClients(searchClients()));
    searchCedula.addEventListener('input', () => renderClients(searchClients()));

    // Botones Configuracion 
    addClientBtn.addEventListener('click', () => showClientModal());
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            clientModal.style.display = 'none';
        });
    });

    // Inicializar
    renderClients();
});
