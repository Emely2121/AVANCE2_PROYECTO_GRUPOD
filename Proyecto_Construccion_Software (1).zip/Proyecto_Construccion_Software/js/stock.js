document.addEventListener('DOMContentLoaded', function() {
    // Referencias a elementos del DOM
    const tableBody = document.querySelector('#stock-table tbody');
    const addItemBtn = document.getElementById('add-item');
    const stockModal = document.getElementById('stock-modal');
    const stockForm = document.getElementById('stock-form');
    const modalTitle = stockModal.querySelector('h3');
    const searchBox = document.getElementById('search-item');
    const categoryFilter = document.getElementById('category-filter');
    const clearFilterBtn = document.getElementById('clear-filter');

    // Cargar datos desde localStorage
    let allItems = JSON.parse(localStorage.getItem('taller_stock')) || [];

    // Función para aplicar filtros 
    function applyFilters() {
        const categoryValue = categoryFilter.value;
        const searchTerm = searchBox.value.toLowerCase().trim();
        
        // Si no hay filtros aplicados, mostrar todos los items
        if (categoryValue === 'all' && searchTerm === '') {
            return allItems;
        }
        
        return allItems.filter(item => {
            // Verificar si el item tiene categoría (manejo de casos undefined)
            const itemCategory = item.categoria ? item.categoria.toLowerCase() : '';
            
            // Filtro por categoría (comparación case insensitive)
            const categoryMatch = categoryValue === 'all' || 
                                itemCategory === categoryValue.toLowerCase();
            
            // Filtro por término de búsqueda
            const searchMatch = searchTerm === '' || 
                              (item.nombre && item.nombre.toLowerCase().includes(searchTerm)) ||
                              (item.codigo && item.codigo.toLowerCase().includes(searchTerm));
            
            return categoryMatch && searchMatch;
        });
    }

    // Mostrar modal para nuevo/editar item
    function showStockModal(item = null) {
        // Modo edición: Rellenar formulario con datos existentes
        if (item) {
            modalTitle.textContent = 'Editar Item';
            document.getElementById('item-name').value = item.nombre || '';
            document.getElementById('item-category').value = item.categoria || '';
            document.getElementById('item-code').value = item.codigo || '';
            document.getElementById('item-stock').value = item.cantidad || 0;
            document.getElementById('item-min-stock').value = item.minStock || 5;
            document.getElementById('item-price').value = item.precio || 0;
            document.getElementById('item-supplier').value = item.proveedor || '';
            document.getElementById('item-notes').value = item.notas || '';
            stockForm.dataset.id = item.id;
        } else {
            // Modo creación: Limpiar formulario
            modalTitle.textContent = 'Nuevo Item';
            stockForm.reset();
            document.getElementById('item-min-stock').value = 5;
            delete stockForm.dataset.id;
        }
        stockModal.style.display = 'flex';
    }

    // Guardar item de inventario 
    stockForm.addEventListener('submit', function(e) {
        e.preventDefault();
         // Recopilar datos del formulario
        const itemData = {
            nombre: document.getElementById('item-name').value,
            categoria: document.getElementById('item-category').value,
            codigo: document.getElementById('item-code').value,
            cantidad: parseFloat(document.getElementById('item-stock').value) || 0,
            minStock: parseFloat(document.getElementById('item-min-stock').value) || 5,
            precio: parseFloat(document.getElementById('item-price').value) || 0,
            proveedor: document.getElementById('item-supplier').value,
            notas: document.getElementById('item-notes').value,
            fecha: new Date().toISOString().split('T')[0]
        };

        // Validación de campos obligatorios
        if (!itemData.nombre || !itemData.categoria || isNaN(itemData.precio)) {
            showNotification('Por favor complete los campos requeridos: Nombre, Categoría y Precio', 'error');
            return;
        }

        if (this.dataset.id) {
            // Editar item existente
            const index = allItems.findIndex(i => i.id == this.dataset.id);
            if (index !== -1) {
                itemData.id = allItems[index].id;
                allItems[index] = itemData;
                showNotification('Item actualizado correctamente');
            }
        } else {
            // Nuevo item de stock 
            itemData.id = Date.now();
            allItems.push(itemData);
            showNotification('Item creado correctamente');
        }
          // Guardar en localStorage y actualizar UI
        localStorage.setItem('taller_stock', JSON.stringify(allItems));
        stockModal.style.display = 'none';
        renderStock();
    });

    // Eliminar item del inventario 
    function deleteItem(id) {
        if (confirm('¿Estás seguro de eliminar este item?')) {
            allItems = allItems.filter(i => i.id != id);
            localStorage.setItem('taller_stock', JSON.stringify(allItems));
            renderStock();
            showNotification('Item eliminado correctamente');
        }
    }

    // Renderizar tabla de items
    function renderStock() {
        tableBody.innerHTML = '';
        
        const filteredItems = applyFilters();
        
        filteredItems.forEach(item => {
            const row = document.createElement('tr');
            // Crear fila para cada item
            row.innerHTML = `
                <td>${item.id}</td>
                <td>${item.nombre}</td>
                <td>${item.categoria || 'N/A'}</td>
                <td class="${item.cantidad <= (item.minStock || 5) ? 'low-stock' : ''}">
                    ${item.cantidad}
                </td>
                <td>${formatCurrency(item.precio)}</td>
                <td>${item.proveedor || 'N/A'}</td>
                <td>
                    <button class="btn-action edit" data-id="${item.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-action delete" data-id="${item.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            // Evento para editar item
            row.querySelector('.edit').addEventListener('click', () => {
                showStockModal(allItems.find(i => i.id == item.id));
            });
            // Evento para eliminar item
            row.querySelector('.delete').addEventListener('click', () => {
                deleteItem(item.id);
            });
            
            tableBody.appendChild(row);
        });
    }

    // Limpiar filtros Evento 
    clearFilterBtn.addEventListener('click', function() {
        categoryFilter.value = 'all';
        searchBox.value = '';
        renderStock();
    });

    // Configuración de eventos
    addItemBtn.addEventListener('click', () => showStockModal());
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            stockModal.style.display = 'none';
        });
    });
    
     // Eventos de filtrado en tiempo real
    searchBox.addEventListener('input', renderStock);
    categoryFilter.addEventListener('change', renderStock);

    // Inicializar
    renderStock();
});