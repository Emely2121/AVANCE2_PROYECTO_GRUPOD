document.addEventListener('DOMContentLoaded', function() {
    // Referencias a elementos del DOM
    const tableBody = document.querySelector('#vehicles-table tbody');
    const addVehicleBtn = document.getElementById('add-vehicle');
    const vehicleModal = document.getElementById('vehicle-modal');
    const vehicleForm = document.getElementById('vehicle-form');
    const modalTitle = document.getElementById('modal-vehicle-title');
    const clientSelect = document.getElementById('vehicle-owner');
    const searchBox = document.getElementById('search-vehicle');
    const typeFilter = document.getElementById('type-filter');
    const yearFilter = document.getElementById('year-filter');
    const clearFiltersBtn = document.getElementById('clear-filters');
    
     // Cargar datos
    let vehicles = JSON.parse(localStorage.getItem('taller_vehiculos')) || [];
    const clients = JSON.parse(localStorage.getItem('taller_clientes')) || [];

    // Función para aplicar todos los filtros a los vehículos
    function applyFilters() {
        const typeValue = typeFilter.value;
        const yearValue = yearFilter.value;
        const searchTerm = searchBox.value.toLowerCase().trim();
        
        // Si no hay filtros aplicados, mostrar todos los vehículos
        if (typeValue === 'all' && !yearValue && searchTerm === '') {
            return vehicles;
        }
        
        return vehicles.filter(vehicle => {
            const client = clients.find(c => c.id == vehicle.clienteId);
            const clientName = client ? client.nombre.toLowerCase() : '';
            
            // Filtro por tipo
            const typeMatch = typeValue === 'all' || 
                             (vehicle.tipo && vehicle.tipo.toLowerCase() === typeValue.toLowerCase());
            
            // Filtro por año
            const yearMatch = !yearValue || 
                             (vehicle.anio && vehicle.anio.toString() === yearValue);
            
            // Filtro por búsqueda
            const searchMatch = searchTerm === '' || 
                (vehicle.marca && vehicle.marca.toLowerCase().includes(searchTerm)) ||
                (vehicle.modelo && vehicle.modelo.toLowerCase().includes(searchTerm)) ||
                (vehicle.placa && vehicle.placa.toLowerCase().includes(searchTerm)) ||
                (vehicle.tipo && vehicle.tipo.toLowerCase().includes(searchTerm)) ||
                clientName.includes(searchTerm);
            
            return typeMatch && yearMatch && searchMatch;
        });
    }

    // Cargar clientes en selector
    function loadClientOptions(selectedId = '') {
        clientSelect.innerHTML = '<option value="">Seleccione un cliente</option>';
        clients.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = client.nombre;
            if (client.id == selectedId) option.selected = true;
            clientSelect.appendChild(option);
        });
    }

    // Mostrar modal para nuevo/editar vehículo
    function showVehicleModal(vehicle = null) {
         // Modo edición: Rellenar formulario con datos existentes
        if (vehicle) {
            modalTitle.textContent = 'Editar Vehículo';
            document.getElementById('vehicle-brand').value = vehicle.marca || '';
            document.getElementById('vehicle-model').value = vehicle.modelo || '';
            document.getElementById('vehicle-type').value = vehicle.tipo || '';
            document.getElementById('vehicle-year').value = vehicle.anio || '';
            document.getElementById('vehicle-plate').value = vehicle.placa || '';
            loadClientOptions(vehicle.clienteId);
            vehicleForm.dataset.id = vehicle.id;
        } else {
             // Modo creación: Limpiar formulario
            modalTitle.textContent = 'Nuevo Vehículo';
            vehicleForm.reset();
            document.getElementById('vehicle-type').value = '';
            loadClientOptions();
            delete vehicleForm.dataset.id;
        }
        vehicleModal.style.display = 'flex';
    }

    // Guardar vehículo (crear o actualizar)
    vehicleForm.addEventListener('submit', function(e) {
        e.preventDefault();
         // Recopilar datos del formulario
        const vehicleData = {
            marca: document.getElementById('vehicle-brand').value,
            modelo: document.getElementById('vehicle-model').value,
            tipo: document.getElementById('vehicle-type').value,
            anio: document.getElementById('vehicle-year').value,
            placa: document.getElementById('vehicle-plate').value,
            clienteId: document.getElementById('vehicle-owner').value
        };

        // Validación de datos 
        if (!vehicleData.marca || !vehicleData.modelo || !vehicleData.tipo || !vehicleData.clienteId) {
            showNotification('Por favor complete todos los campos obligatorios (*)', 'error');
            return;
        }

        if (this.dataset.id) {
            // Editar vehículo existente
            const index = vehicles.findIndex(v => v.id == this.dataset.id);
            if (index !== -1) {
                vehicleData.id = vehicles[index].id;
                vehicles[index] = vehicleData;
                showNotification('Vehículo actualizado correctamente');
            }
        } else {
            // Nuevo vehículo
            vehicleData.id = Date.now();
            vehicles.push(vehicleData);
            showNotification('Vehículo creado correctamente');
        }
        // Guardar en localStorage y actualizar UI
        localStorage.setItem('taller_vehiculos', JSON.stringify(vehicles));
        vehicleModal.style.display = 'none';
        renderVehicles();
    });

    // Eliminar vehículo
    function deleteVehicle(id) {
        if (confirm('¿Estás seguro de eliminar este vehículo?')) {
            vehicles = vehicles.filter(v => v.id != id);
            localStorage.setItem('taller_vehiculos', JSON.stringify(vehicles));
            renderVehicles();
            showNotification('Vehículo eliminado correctamente');
        }
    }

    // Renderizar tabla de vehículos
    function renderVehicles() {
        tableBody.innerHTML = '';
        
        const filteredVehicles = applyFilters();
        
        filteredVehicles.forEach(vehicle => {
            const client = clients.find(c => c.id == vehicle.clienteId);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${vehicle.id}</td>
                <td>${vehicle.marca || ''} ${vehicle.modelo || ''}</td>
                <td>${vehicle.tipo || 'N/A'}</td>
                <td>${vehicle.anio || 'N/A'}</td>
                <td>${vehicle.placa || 'N/A'}</td>
                <td>${client ? client.nombre : 'Cliente no encontrado'}</td>
                <td>
                    <button class="btn-action edit" data-id="${vehicle.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-action delete" data-id="${vehicle.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            // Evento para editar vehículo
            row.querySelector('.edit').addEventListener('click', () => {
                showVehicleModal(vehicles.find(v => v.id == vehicle.id));
            });
           // Evento para eliminar vehículo
            row.querySelector('.delete').addEventListener('click', () => {
                deleteVehicle(vehicle.id);
            });
            
            tableBody.appendChild(row);
        });
    }

    // Limpiar todos los filtros seleccionados 
    function clearFilters() {
        typeFilter.value = 'all';
        yearFilter.value = '';
        searchBox.value = '';
        renderVehicles();
    }

    //  Configursar Eventos
    addVehicleBtn.addEventListener('click', () => showVehicleModal());
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            vehicleModal.style.display = 'none';
        });
    });
    
    // Eventos de filtrado 
    typeFilter.addEventListener('change', renderVehicles);
    yearFilter.addEventListener('input', function() {
        // Solo filtrar si el valor es vacío o un número válido
        if (this.value === '' || (!isNaN(this.value) && this.value >= 1900 && this.value <= new Date().getFullYear())) {
            renderVehicles();
        }
    });
     // Eventos de filtrado en tiempo real
    searchBox.addEventListener('input', renderVehicles);
    clearFiltersBtn.addEventListener('click', clearFilters);

    // Inicializar
    loadClientOptions();
    renderVehicles();
});