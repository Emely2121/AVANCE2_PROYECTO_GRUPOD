// Funciones de utilidad comunes
document.addEventListener('DOMContentLoaded', function() {
    // Inicialización del menú móvil - Toggle de la barra lateral
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    }

    // Actualización automática del año en el footer
    const year = new Date().getFullYear();
    const yearElement = document.getElementById('current-year');
    if (yearElement) {
        yearElement.textContent = year;
    }
});

    // Obtiene datos del localStorage
function getFromStorage(key) {
    const data = localStorage.getItem(`taller_${key}`);
    return data ? JSON.parse(data) : [];
}
   // Guarda datos en localStorage
function saveToStorage(key, data) {
    localStorage.setItem(`taller_${key}`, JSON.stringify(data));
}

   // Formatea una fecha al formato español (día mes año)
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
}
   // Formatea un número como moneda en USD
function formatCurrency(amount) {
    if (isNaN(amount)) return '$0.00';
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2
    }).format(amount);
}

//  Muestra una notificación temporal con animación
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}
