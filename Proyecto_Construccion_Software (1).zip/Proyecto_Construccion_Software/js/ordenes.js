document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM - Referencias a los elementos HTML que se usarán en el script
    const tableBody = document.querySelector('#orders-table tbody');
    const addOrderBtn = document.getElementById('add-order');
    const orderModal = document.getElementById('order-modal');
    const orderForm = document.getElementById('order-form');
    const modalTitle = orderModal.querySelector('h3');
    const clientSelect = document.getElementById('order-client');
    const vehicleSelect = document.getElementById('order-vehicle');
    const itemsContainer = document.querySelector('.items-list');
    const statusFilter = document.getElementById('status-filter');
    const dateFilter = document.getElementById('date-filter');
    const searchBox = document.querySelector('.search-box input');
    const clearFiltersBtn = document.getElementById('clear-filters') || createClearFiltersButton();

    // Datos - Carga de datos desde localStorage (persistencia de datos)
    let allOrders = JSON.parse(localStorage.getItem('taller_ordenes')) || [];
    let clients = JSON.parse(localStorage.getItem('taller_clientes')) || [];
    let vehicles = JSON.parse(localStorage.getItem('taller_vehiculos')) || [];

    // Crear botón para limpiar filtros
    function createClearFiltersButton() {
        const btn = document.createElement('button');
        btn.innerHTML = '<i class="fas fa-times"></i> Limpiar filtros';
        btn.className = 'btn-primary';
        btn.id = 'clear-filters';
        document.querySelector('.filters').appendChild(btn);
        return btn;
    }

    // Función para aplicar todos los filtros (búsqueda, estado, fecha)
    function applyFilters() {
        const statusValue = statusFilter.value;
        const dateValue = dateFilter.value;
        const searchTerm = searchBox.value.toLowerCase().trim();
        
        let filteredOrders = [...allOrders];
        
        // Filtrar por estado (pendiente, en proceso, completado, etc.
        if (statusValue !== 'all') {
            filteredOrders = filteredOrders.filter(order => order.estado === statusValue);
        }
        
        // Filtrar por fecha
        if (dateValue) {
            filteredOrders = filteredOrders.filter(order => {
                const orderDate = new Date(order.fecha).toISOString().split('T')[0];
                return orderDate === dateValue;
            });
        }
        
        // Filtrar por término de búsqueda en multiples campos
        if (searchTerm) {
            filteredOrders = filteredOrders.filter(order => 
                order.clienteNombre.toLowerCase().includes(searchTerm) || 
                order.vehiculoInfo.toLowerCase().includes(searchTerm) ||
                order.id.toString().includes(searchTerm) ||
                order.descripcion.toLowerCase().includes(searchTerm)
            );
        }
                
        return filteredOrders;
    }

    // Carga los vehículos asociados a un cliente específico
    function loadClientOptions(selectedId = '') {
        clientSelect.innerHTML = '<option value="">Seleccione un cliente</option>';
        clients.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = client.nombre;
            if (client.id == selectedId) option.selected = true;
            clientSelect.appendChild(option);
        });
    }

    // Cargar vehículos de un cliente
    function loadVehicleOptions(clientId, selectedId = '') {
        vehicleSelect.innerHTML = '<option value="">Seleccione un vehículo</option>';
        if (!clientId) return;
        
        const clientVehicles = vehicles.filter(v => v.clienteId == clientId);
        clientVehicles.forEach(vehicle => {
            const option = document.createElement('option');
            option.value = vehicle.id;
            option.textContent = `${vehicle.marca} ${vehicle.modelo}`;
            if (vehicle.id == selectedId) option.selected = true;
            vehicleSelect.appendChild(option);
        });
    }

    // Calcula el total general de la orden (suma de todos los ítems menos descuento)
    function calculateItemTotal(itemRow) {
        const qty = parseFloat(itemRow.querySelector('.item-qty').value) || 0;
        const price = parseFloat(itemRow.querySelector('.item-price').value) || 0;
        const total = qty * price;
        itemRow.querySelector('.item-total').textContent = formatCurrency(total);
        return total;
    }

    // Calcular total de la orden
    function calculateOrderTotal() {
        let subtotal = 0;
        document.querySelectorAll('.item-row:not(#item-template)').forEach(row => {
            subtotal += calculateItemTotal(row);
        });
        
        const discount = parseFloat(document.getElementById('order-discount').value) || 0;
        const total = subtotal - discount;
        
        document.querySelector('.total-amount').textContent = formatCurrency(total > 0 ? total : 0);
        return total;
    }

    // Configura los eventos para cada fila de ítem (cambios en cantidad, precio, eliminación)
    function setupItemEvents(itemRow) {
        itemRow.querySelector('.item-qty').addEventListener('input', calculateOrderTotal);
        itemRow.querySelector('.item-price').addEventListener('input', calculateOrderTotal);
        itemRow.querySelector('.remove-item').addEventListener('click', function() {
            if (confirm('¿Eliminar este item?')) {
                itemRow.remove();
                calculateOrderTotal();
            }
        });
    }

    // Agregar nuevo item
    document.getElementById('add-item').addEventListener('click', function() {
        const newItem = document.getElementById('item-template').cloneNode(true);
        newItem.id = '';
        newItem.style.display = 'flex';
        itemsContainer.insertBefore(newItem, this);
        setupItemEvents(newItem);
        calculateOrderTotal();
    });

    // Mostrar modal de orden (nueva o editar)
    function showOrderModal(order = null) {
        if (order) {
            modalTitle.textContent = 'Editar Orden';
            document.getElementById('order-date').value = order.fecha;
            document.getElementById('order-description').value = order.descripcion;
            document.getElementById('order-status').value = order.estado;
            document.getElementById('order-discount').value = order.descuento || 0;
            
            // Limpiar items anteriores
            document.querySelectorAll('.item-row:not(#item-template)').forEach(row => row.remove());
            
            // Agregar items
            if (order.items && order.items.length) {
                order.items.forEach(item => {
                    const newItem = document.getElementById('item-template').cloneNode(true);
                    newItem.id = '';
                    newItem.style.display = 'flex';
                    newItem.querySelector('.item-desc').value = item.descripcion;
                    newItem.querySelector('.item-qty').value = item.cantidad;
                    newItem.querySelector('.item-price').value = item.precio;
                    itemsContainer.insertBefore(newItem, document.getElementById('add-item'));
                    setupItemEvents(newItem);
                });
            }
            
            loadClientOptions(order.clienteId);
            setTimeout(() => {
                loadVehicleOptions(order.clienteId, order.vehiculoId);
            }, 100);
            
            orderForm.dataset.id = order.id;
        } else {
            // Modo creación: Limpiar formulario
            modalTitle.textContent = 'Nueva Orden';
            orderForm.reset();
            document.getElementById('order-date').value = new Date().toISOString().split('T')[0];
            document.getElementById('order-status').value = 'pending';
            document.getElementById('order-discount').value = '0';
            
            // Limpiar items
            document.querySelectorAll('.item-row:not(#item-template)').forEach(row => row.remove());
            
            loadClientOptions();
            vehicleSelect.innerHTML = '<option value="">Seleccione un vehículo</option>';
            delete orderForm.dataset.id;
        }
        
        calculateOrderTotal();
        orderModal.style.display = 'flex';
    }

    // Guardar orden
    orderForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Recopila información de todos los ítems
        const items = [];
        document.querySelectorAll('.item-row:not(#item-template)').forEach(row => {
            items.push({
                descripcion: row.querySelector('.item-desc').value,
                cantidad: parseFloat(row.querySelector('.item-qty').value) || 0,
                precio: parseFloat(row.querySelector('.item-price').value) || 0,
                total: parseFloat(row.querySelector('.item-total').textContent.replace(/[^0-9.-]+/g,"")) || 0
            });
        });
      // Validación: al menos un ítem requerido
        if (items.length === 0) {
            alert('Debe agregar al menos un item a la orden');
            return;
        }
     // Prepara el objeto de datos de la orden
        const orderData = {
            fecha: document.getElementById('order-date').value,
            descripcion: document.getElementById('order-description').value,
            estado: document.getElementById('order-status').value,
            items: items,
            descuento: parseFloat(document.getElementById('order-discount').value) || 0,
            total: calculateOrderTotal(),
            clienteId: document.getElementById('order-client').value,
            vehiculoId: document.getElementById('order-vehicle').value,
            clienteNombre: clientSelect.options[clientSelect.selectedIndex].text,
            vehiculoInfo: vehicleSelect.options[vehicleSelect.selectedIndex].text
        };
     // Validación: cliente y vehículo requeridos    
        if (!orderData.clienteId || !orderData.vehiculoId) {
            alert('Debe seleccionar un cliente y un vehículo');
            return;
        }

        if (this.dataset.id) {
            // Modo edición - actualiza la orden existente
            const index = allOrders.findIndex(o => o.id == this.dataset.id);
            if (index !== -1) {
                orderData.id = allOrders[index].id;
                allOrders[index] = orderData;
            }
        } else {
            // Modo creación - agrega una nueva orden
            orderData.id = Date.now();
            allOrders.push(orderData);
        }
        // Guarda en localStorage y actualiza la UI
        localStorage.setItem('taller_ordenes', JSON.stringify(allOrders));
        orderModal.style.display = 'none';
        renderOrders();
        showNotification('Orden guardada correctamente');
    });

    // Renderizar órdenes
    function renderOrders() {
        tableBody.innerHTML = '';
        
        const filteredOrders = applyFilters();
        // Muestra las órdenes en orden inverso (más recientes primero)
        filteredOrders.slice().reverse().forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.id}</td>
                <td>${order.clienteNombre || 'N/A'}</td>
                <td>${order.vehiculoInfo || 'N/A'}</td>
                <td>${formatDate(order.fecha)}</td>
                <td><span class="status-badge status-${order.estado}">${order.estado}</span></td>
                <td>${formatCurrency(order.total)}</td>
                <td>
                    <button class="btn-action edit" data-id="${order.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-action delete" data-id="${order.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            // Configura eventos para editar orden
            row.querySelector('.edit').addEventListener('click', () => {
                showOrderModal(allOrders.find(o => o.id == order.id));
            });
            // Configura eventos para eliminar orden
            row.querySelector('.delete').addEventListener('click', () => {
                if (confirm('¿Estás seguro de eliminar esta orden?')) {
                    allOrders = allOrders.filter(o => o.id != order.id);
                    localStorage.setItem('taller_ordenes', JSON.stringify(allOrders));
                    renderOrders();
                }
            });
            
            tableBody.appendChild(row);
        });
    }

    // Limpiar filtros
    clearFiltersBtn.addEventListener('click', function() {
        statusFilter.value = 'all';
        dateFilter.value = '';
        searchBox.value = '';
        renderOrders();
    });

   // Configuración de eventos principales
    addOrderBtn.addEventListener('click', () => showOrderModal());
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            orderModal.style.display = 'none';
        });
    });
    clientSelect.addEventListener('change', (e) => loadVehicleOptions(e.target.value));
    document.getElementById('order-discount').addEventListener('input', calculateOrderTotal);
    statusFilter.addEventListener('change', renderOrders);
    dateFilter.addEventListener('change', renderOrders);
    searchBox.addEventListener('input', renderOrders);

    // Inicializar
    document.getElementById('item-template').style.display = 'none';
    setupItemEvents(document.getElementById('item-template'));
    loadClientOptions();
    renderOrders();

    // Función para mostrar notificaciones
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => notification.remove(), 500);
        }, 3000);
    }
});